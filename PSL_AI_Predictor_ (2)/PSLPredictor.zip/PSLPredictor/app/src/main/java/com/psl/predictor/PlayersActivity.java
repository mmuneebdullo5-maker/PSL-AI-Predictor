package com.psl.predictor;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import java.util.List;

public class PlayersActivity extends AppCompatActivity {

    private MaterialButton btnBat, btnBowl;
    private LinearLayout   listContainer;
    private DataManager    dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_players);
        dm            = DataManager.getInstance(this);
        btnBat        = findViewById(R.id.btnBat);
        btnBowl       = findViewById(R.id.btnBowl);
        listContainer = findViewById(R.id.listContainer);

        loadBatsmen();
        btnBat .setOnClickListener(v -> { selectBtn(btnBat, btnBowl); loadBatsmen(); });
        btnBowl.setOnClickListener(v -> { selectBtn(btnBowl, btnBat); loadBowlers(); });
    }

    private void selectBtn(MaterialButton on, MaterialButton off) {
        on .setBackgroundColor(0xFFFFA500);
        off.setBackgroundColor(0xFF1A1A2E);
    }

    private void loadBatsmen() {
        listContainer.removeAllViews();
        List<String[]> list = dm.getTopBatsmen();
        for (int i = 0; i < list.size(); i++) {
            String[] p = list.get(i);
            addCard(i + 1, p[0], p[1],
                "Runs: " + p[2],
                "Avg: " + p[3] + "  |  SR: " + p[4] + "  |  HS: " + p[5],
                "50s: " + p[6] + "  |  100s: " + p[7]);
        }
    }

    private void loadBowlers() {
        listContainer.removeAllViews();
        List<String[]> list = dm.getTopBowlers();
        for (int i = 0; i < list.size(); i++) {
            String[] p = list.get(i);
            addCard(i + 1, p[0], p[1],
                "Wickets: " + p[2],
                "Avg: " + p[3] + "  |  Economy: " + p[4],
                "Best: " + p[5]);
        }
    }

    private void addCard(int rank, String name, String team,
                         String s1, String s2, String s3) {
        View card = LayoutInflater.from(this)
            .inflate(R.layout.item_player_card, listContainer, false);
        ((TextView) card.findViewById(R.id.tvRank)) .setText(String.valueOf(rank));
        ((TextView) card.findViewById(R.id.tvName)) .setText(name);
        ((TextView) card.findViewById(R.id.tvTeam)) .setText(team);
        ((TextView) card.findViewById(R.id.tvStat1)).setText(s1);
        ((TextView) card.findViewById(R.id.tvStat2)).setText(s2);
        ((TextView) card.findViewById(R.id.tvStat3)).setText(s3);
        listContainer.addView(card);
    }
}
