package com.psl.predictor;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.*;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class TeamStatsActivity extends AppCompatActivity {

    private Spinner          spinnerTeam;
    private MaterialButton   btnLoad, btnAddTeamToggle, btnSaveTeam, btnDeleteTeam;
    private MaterialCardView cardAddTeam;
    private LinearLayout     layoutStatsContainer;
    private EditText         etNewTeamName, etNewTeamCity;
    private TextView tvTeamName, tvCity, tvTitles, tvPlayed,
                     tvWins, tvLosses, tvWR, tvAvg, tvPos, tvResult;
    private BarChart barChart;
    private PieChart pieChart;
    private DataManager dm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_team_stats);
        dm = DataManager.getInstance(this);

        spinnerTeam     = findViewById(R.id.spinnerTeam);
        btnLoad         = findViewById(R.id.btnLoad);
        btnDeleteTeam   = findViewById(R.id.btnDeleteTeam);
        btnAddTeamToggle = findViewById(R.id.btnAddTeamToggle);
        btnSaveTeam     = findViewById(R.id.btnSaveTeam);
        cardAddTeam     = findViewById(R.id.cardAddTeam);
        layoutStatsContainer = findViewById(R.id.layoutStatsContainer);
        etNewTeamName   = findViewById(R.id.etNewTeamName);
        etNewTeamCity   = findViewById(R.id.etNewTeamCity);

        tvTeamName  = findViewById(R.id.tvTeamName);
        tvCity      = findViewById(R.id.tvCity);
        tvTitles    = findViewById(R.id.tvTitles);
        tvPlayed    = findViewById(R.id.tvPlayed);
        tvWins      = findViewById(R.id.tvWins);
        tvLosses    = findViewById(R.id.tvLosses);
        tvWR        = findViewById(R.id.tvWR);
        tvAvg       = findViewById(R.id.tvAvg);
        tvPos       = findViewById(R.id.tvPos);
        tvResult    = findViewById(R.id.tvResult);

        barChart    = findViewById(R.id.barChart);
        pieChart    = findViewById(R.id.pieChart);

        refreshTeamSpinner();

        spinnerTeam.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String team = spinnerTeam.getSelectedItem().toString();
                if (dm.isCustomTeam(team)) {
                    btnDeleteTeam.setVisibility(View.VISIBLE);
                } else {
                    btnDeleteTeam.setVisibility(View.GONE);
                }
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        });

        btnLoad.setOnClickListener(v -> {
            String team = spinnerTeam.getSelectedItem().toString();
            if (team.equals("Select Team")) {
                Toast.makeText(this, "Please select a team", Toast.LENGTH_SHORT).show();
                return;
            }
            loadStats(team);
        });

        btnDeleteTeam.setOnClickListener(v -> {
            String team = spinnerTeam.getSelectedItem().toString();
            dm.deleteCustomTeam(team);
            Toast.makeText(this, "Team " + team + " deleted!", Toast.LENGTH_SHORT).show();
            btnDeleteTeam.setVisibility(View.GONE);
            layoutStatsContainer.setVisibility(View.GONE);
            refreshTeamSpinner();
        });

        btnAddTeamToggle.setOnClickListener(v -> {
            if (cardAddTeam.getVisibility() == View.VISIBLE) {
                cardAddTeam.setVisibility(View.GONE);
                btnAddTeamToggle.setText("+ Add New Team");
            } else {
                cardAddTeam.setVisibility(View.VISIBLE);
                btnAddTeamToggle.setText("- Close");
            }
        });

        btnSaveTeam.setOnClickListener(v -> {
            String name = etNewTeamName.getText().toString().trim();
            String city = etNewTeamCity.getText().toString().trim();

            if (name.isEmpty() || city.isEmpty()) {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
                return;
            }

            dm.addCustomTeam(name, city);
            Toast.makeText(this, "Team added successfully!", Toast.LENGTH_SHORT).show();
            
            etNewTeamName.setText("");
            etNewTeamCity.setText("");
            cardAddTeam.setVisibility(View.GONE);
            btnAddTeamToggle.setText("+ Add New Team");
            
            refreshTeamSpinner();
        });
    }

    private void loadStats(String teamName) {
        Map<String, String> s = dm.getTeamStats(teamName);
        tvTeamName.setText(teamName);
        tvCity   .setText("🏙️ City: "          + s.getOrDefault("city",   "-"));
        tvTitles .setText("🏆 PSL Titles: "    + s.getOrDefault("titles", "0"));
        tvPlayed .setText("📋 Matches Played: " + s.getOrDefault("played", "0"));
        tvWins   .setText("✅ Wins: "           + s.getOrDefault("wins",   "0"));
        tvLosses .setText("❌ Losses: "         + s.getOrDefault("losses", "0"));
        tvWR     .setText("📊 Win Rate: "       + s.getOrDefault("wr",     "0%"));
        tvAvg    .setText("🏏 Avg Score: "      + s.getOrDefault("avg",    "0"));
        tvPos    .setText("📍 2026 Position: "  + s.getOrDefault("pos",    "-"));
        tvResult .setText("🎯 2026 Result: "    + s.getOrDefault("result", "-"));

        setupBarChart(teamName);
        setupPieChart(s);

        layoutStatsContainer.setVisibility(View.VISIBLE);
    }

    private void setupBarChart(String teamName) {
        List<BarEntry> entries = new ArrayList<>();
        List<Map<String, String>> matches = dm.getMatches();
        List<String> labels = new ArrayList<>();
        int count = 0;

        for (Map<String, String> m : matches) {
            String t1 = m.get("team1");
            String t2 = m.get("team2");
            if (teamName.equals(t1) || teamName.equals(t2)) {
                String val = teamName.equals(t1) ? m.get("t1s") : m.get("t2s");
                if (val != null) {
                    try {
                        float score = Float.parseFloat(val);
                        if (score > 0) {
                            entries.add(new BarEntry(count, score));
                            labels.add("M" + m.get("id"));
                            count++;
                            if (count >= 5) break;
                        }
                    } catch (Exception e) {}
                }
            }
        }

        if (entries.isEmpty()) {
            entries.add(new BarEntry(0, 45f)); entries.add(new BarEntry(1, 60f));
            entries.add(new BarEntry(2, 30f)); entries.add(new BarEntry(3, 85f));
            entries.add(new BarEntry(4, 55f));
            labels.add("M1"); labels.add("M2"); labels.add("M3"); labels.add("M4"); labels.add("M5");
        }

        BarDataSet dataSet = new BarDataSet(entries, "Runs in Last 5 Matches");
        dataSet.setColors(new int[]{
            Color.parseColor("#4CAF50"), Color.parseColor("#FFC107"),
            Color.parseColor("#F44336"), Color.parseColor("#2196F3"),
            Color.parseColor("#4CAF50")
        });
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(11f);

        BarData barData = new BarData(dataSet);
        barData.setBarWidth(0.6f);
        barChart.setData(barData);
        barChart.getDescription().setEnabled(false);
        barChart.getLegend().setTextColor(Color.WHITE);
        barChart.setDrawGridBackground(false);

        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setTextColor(Color.WHITE);
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setDrawGridLines(false);
        xAxis.setGranularity(1f);

        barChart.getAxisLeft().setTextColor(Color.WHITE);
        barChart.getAxisLeft().setDrawGridLines(true);
        barChart.getAxisLeft().setGridColor(Color.parseColor("#33FFFFFF"));
        barChart.getAxisRight().setEnabled(false);
        
        barChart.animateY(1200);
        barChart.invalidate();
    }

    private void setupPieChart(Map<String, String> stats) {
        float wins = 0, losses = 0, nr = 0, tied = 0;
        try {
            wins = Float.parseFloat(stats.getOrDefault("wins", "0"));
            losses = Float.parseFloat(stats.getOrDefault("losses", "0"));
            nr = Float.parseFloat(stats.getOrDefault("nr", "0"));
            tied = Float.parseFloat(stats.getOrDefault("tied", "0"));
        } catch (Exception e) {}

        if (wins == 0 && losses == 0) {
            wins = 40f; losses = 30f; nr = 20f; tied = 10f;
        }

        List<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry(wins, "Wins"));
        entries.add(new PieEntry(losses, "Losses"));
        entries.add(new PieEntry(nr, "No Result"));
        entries.add(new PieEntry(tied, "Tied"));

        PieDataSet dataSet = new PieDataSet(entries, "");
        dataSet.setColors(new int[]{
            Color.parseColor("#E91E63"), Color.parseColor("#FF9800"),
            Color.parseColor("#FFEB3B"), Color.parseColor("#4CAF50")
        });
        dataSet.setValueTextColor(Color.WHITE);
        dataSet.setValueTextSize(13f);
        dataSet.setSliceSpace(3f);

        PieData pieData = new PieData(dataSet);
        pieChart.setData(pieData);
        pieChart.setHoleColor(Color.TRANSPARENT);
        pieChart.setTransparentCircleRadius(0f);
        pieChart.setHoleRadius(50f);
        pieChart.setCenterText("Stats");
        pieChart.setCenterTextColor(Color.WHITE);
        pieChart.setCenterTextSize(16f);
        pieChart.getLegend().setTextColor(Color.WHITE);
        pieChart.getLegend().setWordWrapEnabled(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawEntryLabels(true);
        pieChart.setEntryLabelColor(Color.BLACK);
        pieChart.setEntryLabelTextSize(10f);
        
        pieChart.animateXY(1200, 1200);
        pieChart.invalidate();
    }

    private void refreshTeamSpinner() {
        List<String> teams = new ArrayList<>();
        teams.add("Select Team");
        teams.addAll(dm.getTeamNames());
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, teams);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerTeam.setAdapter(adapter);
    }
}
