package com.psl.predictor;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.*;

public class DataManager {

    private static DataManager instance;
    private JSONObject data;
    private SharedPreferences prefs;
    private static final String PREF_NAME = "PSL_PREFS";
    private static final String KEY_CUSTOM_TEAMS = "CUSTOM_TEAMS";

    public static DataManager getInstance(Context ctx) {
        if (instance == null) instance = new DataManager(ctx);
        return instance;
    }

    private DataManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        try {
            InputStream is = ctx.getAssets().open("psl_data.json");
            byte[] buf = new byte[is.available()];
            is.read(buf);
            is.close();
            data = new JSONObject(new String(buf));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public List<Map<String, String>> getMatches() {
        List<Map<String, String>> list = new ArrayList<>();
        try {
            JSONArray arr = data.getJSONArray("matches");
            for (int i = arr.length() - 1; i >= 0; i--) {
                JSONObject o = arr.getJSONObject(i);
                if (o.getInt("t1s") == 0 && !o.getString("winner").equals("No Result")) continue;
                Map<String, String> m = new LinkedHashMap<>();
                m.put("id",     String.valueOf(o.getInt("id")));
                m.put("date",   o.getString("date"));
                m.put("stage",  o.getString("stage"));
                m.put("venue",  o.getString("venue"));
                m.put("team1",  o.getString("team1"));
                m.put("team2",  o.getString("team2"));
                m.put("t1s",    String.valueOf(o.getInt("t1s")));
                m.put("t1w",    String.valueOf(o.getInt("t1w")));
                m.put("t2s",    String.valueOf(o.getInt("t2s")));
                m.put("t2w",    String.valueOf(o.getInt("t2w")));
                m.put("winner", o.getString("winner"));
                m.put("result", o.getString("result"));
                m.put("pom",    o.getString("pom"));
                list.add(m);
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public String getTeamCode(String teamName) {
        try {
            JSONArray arr = data.getJSONArray("teams");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject t = arr.getJSONObject(i);
                if (t.getString("name").equals(teamName)) return t.getString("code");
            }
        } catch (Exception e) {}
        return teamName.length() > 3 ? teamName.substring(0, 3).toUpperCase() : teamName.toUpperCase();
    }

    public List<String> getTeamNames() {
        List<String> list = new ArrayList<>();
        try {
            JSONArray arr = data.getJSONArray("teams");
            for (int i = 0; i < arr.length(); i++) {
                list.add(arr.getJSONObject(i).getString("name"));
            }
            list.addAll(getCustomTeamNames());
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<String> getCustomTeamNames() {
        List<String> list = new ArrayList<>();
        try {
            String custom = prefs.getString(KEY_CUSTOM_TEAMS, "[]");
            JSONArray customArr = new JSONArray(custom);
            for (int i = 0; i < customArr.length(); i++) {
                list.add(customArr.getJSONObject(i).getString("name"));
            }
        } catch (Exception e) {}
        return list;
    }

    public boolean isCustomTeam(String teamName) {
        return getCustomTeamNames().contains(teamName);
    }

    public void addCustomTeam(String name, String city) {
        try {
            String custom = prefs.getString(KEY_CUSTOM_TEAMS, "[]");
            JSONArray customArr = new JSONArray(custom);
            JSONObject newTeam = new JSONObject();
            newTeam.put("name", name);
            newTeam.put("city", city);
            newTeam.put("titles", 0);
            newTeam.put("pos", "N/A");
            newTeam.put("result", "N/A");
            customArr.put(newTeam);
            prefs.edit().putString(KEY_CUSTOM_TEAMS, customArr.toString()).apply();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public void deleteCustomTeam(String name) {
        try {
            String custom = prefs.getString(KEY_CUSTOM_TEAMS, "[]");
            JSONArray customArr = new JSONArray(custom);
            JSONArray newArr = new JSONArray();
            for (int i = 0; i < customArr.length(); i++) {
                if (!customArr.getJSONObject(i).getString("name").equals(name)) {
                    newArr.put(customArr.getJSONObject(i));
                }
            }
            prefs.edit().putString(KEY_CUSTOM_TEAMS, newArr.toString()).apply();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public List<String> getVenues() {
        return Arrays.asList("National Stadium, Karachi", "Gaddafi Stadium, Lahore", "Rawalpindi Cricket Stadium", "Multan Cricket Stadium", "Arbab Niaz Stadium, Peshawar", "Bugti Stadium, Quetta");
    }

    public Map<String, String> getTeamStats(String teamName) {
        Map<String, String> stats = new LinkedHashMap<>();
        try {
            JSONArray matchesArr = data.getJSONArray("matches");
            int played = 0, wins = 0, losses = 0, nr = 0, tied = 0, totalScore = 0, scoreCount = 0;
            for (int i = 0; i < matchesArr.length(); i++) {
                JSONObject m = matchesArr.getJSONObject(i);
                String t1 = m.optString("team1", "");
                String t2 = m.optString("team2", "");
                String winner = m.optString("winner", "");
                int t1s   = m.optInt("t1s", 0);
                int t2s   = m.optInt("t2s", 0);

                if (t1.equals(teamName) || t2.equals(teamName)) {
                    played++;
                    if (winner.equals(teamName)) wins++;
                    else if (winner.equals("No Result")) nr++;
                    else if (winner.equals("Tied")) tied++;
                    else if (!winner.isEmpty()) losses++;

                    if (t1.equals(teamName) && t1s > 0) { totalScore += t1s; scoreCount++; }
                    if (t2.equals(teamName) && t2s > 0) { totalScore += t2s; scoreCount++; }
                }
            }
            JSONArray teams = data.getJSONArray("teams");
            boolean found = false;
            for (int i = 0; i < teams.length(); i++) {
                JSONObject t = teams.getJSONObject(i);
                if (t.getString("name").equals(teamName)) {
                    stats.put("city",   t.getString("city"));
                    stats.put("titles", String.valueOf(t.optInt("titles", t.optInt("psl_titles", 0))));
                    stats.put("pos",    t.optString("pos", t.optString("league_position_2026", "N/A")));
                    stats.put("result", t.optString("result", t.optString("playoff_result_2026", "N/A")));
                    found = true;
                    break;
                }
            }
            if (!found) {
                String custom = prefs.getString(KEY_CUSTOM_TEAMS, "[]");
                JSONArray customArr = new JSONArray(custom);
                for (int i = 0; i < customArr.length(); i++) {
                    JSONObject t = customArr.getJSONObject(i);
                    if (t.getString("name").equals(teamName)) {
                        stats.put("city",   t.getString("city"));
                        stats.put("titles", "0");
                        stats.put("pos",    "N/A");
                        stats.put("result", "N/A");
                        break;
                    }
                }
            }
            double avg = scoreCount > 0 ? (double) totalScore / scoreCount : 0;
            double wr  = played > 0 ? (double) wins * 100 / played : 0;
            stats.put("played", String.valueOf(played));
            stats.put("wins",   String.valueOf(wins));
            stats.put("losses", String.valueOf(losses));
            stats.put("nr",     String.valueOf(nr));
            stats.put("tied",   String.valueOf(tied));
            stats.put("wr",     String.format("%.1f%%", wr));
            stats.put("avg",    String.format("%.1f", avg));
        } catch (Exception e) { e.printStackTrace(); }
        return stats;
    }

    public List<String[]> getTopBatsmen() {
        List<String[]> list = new ArrayList<>();
        try {
            JSONArray arr = data.getJSONArray("batsmen");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject p = arr.getJSONObject(i);
                list.add(new String[]{p.getString("name"), p.getString("team"), String.valueOf(p.getInt("runs")), String.valueOf(p.getDouble("avg")), String.valueOf(p.getDouble("sr")), p.getString("hs"), String.valueOf(p.getInt("50s")), String.valueOf(p.getInt("100s"))});
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }

    public List<String[]> getTopBowlers() {
        List<String[]> list = new ArrayList<>();
        try {
            JSONArray arr = data.getJSONArray("bowlers");
            for (int i = 0; i < arr.length(); i++) {
                JSONObject p = arr.getJSONObject(i);
                list.add(new String[]{p.getString("name"), p.getString("team"), String.valueOf(p.getInt("wkts")), String.valueOf(p.getDouble("avg")), String.valueOf(p.getDouble("eco")), p.getString("best")});
            }
        } catch (Exception e) { e.printStackTrace(); }
        return list;
    }
}
