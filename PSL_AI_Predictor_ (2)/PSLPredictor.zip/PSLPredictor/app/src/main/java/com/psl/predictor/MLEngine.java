package com.psl.predictor;

import android.content.Context;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.InputStream;
import java.util.*;

/**
 * PSL AI Engine — Real ML inference in Java
 * Runs Gradient Boosting (score) + Random Forest (win) directly
 */
public class MLEngine {

    private static MLEngine instance;

    private double   gbInitScore;
    private double   gbLearningRate;
    private int      gbNTrees;
    private int[][]  gbLeft, gbRight, gbFeature;
    private double[][] gbThreshold, gbValue;

    private int      rfNTrees;
    private int[][]  rfLeft, rfRight, rfFeature;
    private double[][] rfThreshold;
    private double[][][] rfValue;

    private Map<String, Integer> teamEnc   = new HashMap<>();
    private Map<String, Integer> venueEnc  = new HashMap<>();
    private Map<String, Integer> decEnc    = new HashMap<>();

    public static MLEngine getInstance(Context ctx) {
        if (instance == null) instance = new MLEngine(ctx);
        return instance;
    }

    private MLEngine(Context ctx) {
        try {
            InputStream is = ctx.getAssets().open("psl_model.json");
            byte[] buf = new byte[is.available()];
            is.read(buf);
            is.close();
            JSONObject root = new JSONObject(new String(buf));
            loadEncoders(root);
            loadScoreModel(root.getJSONObject("score_model"));
            loadWinModel(root.getJSONObject("win_model"));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadEncoders(JSONObject root) throws Exception {
        JSONObject enc = root.getJSONObject("encoders");
        JSONArray teams = enc.getJSONArray("teams");
        for (int i = 0; i < teams.length(); i++) teamEnc.put(teams.getString(i), i);
        JSONArray venues = enc.getJSONArray("venues");
        for (int i = 0; i < venues.length(); i++) venueEnc.put(venues.getString(i), i);
        JSONArray decs = enc.getJSONArray("decisions");
        for (int i = 0; i < decs.length(); i++) decEnc.put(decs.getString(i), i);
    }

    private String normalizeVenue(String venue) {
        if (venue == null) return "Gaddafi Stadium";
        // Mapping new venues to model-trained venues for better accuracy
        if (venue.contains("Karachi")) return "National Bank Cricket Arena";
        if (venue.contains("Lahore")) return "Gaddafi Stadium";
        if (venue.contains("Rawalpindi")) return "Gaddafi Stadium"; 
        if (venue.contains("Multan")) return "Gaddafi Stadium";
        return "Gaddafi Stadium";
    }

    private void loadScoreModel(JSONObject m) throws Exception {
        gbInitScore    = m.getDouble("init_score");
        gbLearningRate = m.getDouble("learning_rate");
        JSONArray trees = m.getJSONArray("trees");
        gbNTrees = trees.length();
        gbLeft = new int[gbNTrees][]; gbRight = new int[gbNTrees][]; gbFeature = new int[gbNTrees][];
        gbThreshold = new double[gbNTrees][]; gbValue = new double[gbNTrees][];
        for (int t = 0; t < gbNTrees; t++) {
            JSONObject tree = trees.getJSONObject(t);
            gbLeft[t] = toIntArray(tree.getJSONArray("children_left"));
            gbRight[t] = toIntArray(tree.getJSONArray("children_right"));
            gbFeature[t] = toIntArray(tree.getJSONArray("feature"));
            gbThreshold[t] = toDoubleArray(tree.getJSONArray("threshold"));
            gbValue[t] = toDoubleArray(tree.getJSONArray("value"));
        }
    }

    private void loadWinModel(JSONObject m) throws Exception {
        JSONArray trees = m.getJSONArray("trees");
        rfNTrees = trees.length();
        rfLeft = new int[rfNTrees][]; rfRight = new int[rfNTrees][]; rfFeature = new int[rfNTrees][];
        rfThreshold = new double[rfNTrees][]; rfValue = new double[rfNTrees][][];
        for (int t = 0; t < rfNTrees; t++) {
            JSONObject tree = trees.getJSONObject(t);
            rfLeft[t] = toIntArray(tree.getJSONArray("children_left"));
            rfRight[t] = toIntArray(tree.getJSONArray("children_right"));
            rfFeature[t] = toIntArray(tree.getJSONArray("feature"));
            rfThreshold[t] = toDoubleArray(tree.getJSONArray("threshold"));
            JSONArray vals = tree.getJSONArray("value");
            rfValue[t] = new double[vals.length()][2];
            for (int n = 0; n < vals.length(); n++) {
                JSONArray node = vals.getJSONArray(n);
                rfValue[t][n][0] = node.getDouble(0);
                rfValue[t][n][1] = node.getDouble(1);
            }
        }
    }

    private double traverseGB(int treeIdx, double[] features) {
        int node = 0;
        while (gbLeft[treeIdx][node] != -1) {
            int feat = gbFeature[treeIdx][node];
            if (features[feat] <= gbThreshold[treeIdx][node]) node = gbLeft[treeIdx][node];
            else node = gbRight[treeIdx][node];
        }
        return gbValue[treeIdx][node];
    }

    private double[] traverseRF(int treeIdx, double[] features) {
        int node = 0;
        while (rfLeft[treeIdx][node] != -1) {
            int feat = rfFeature[treeIdx][node];
            if (features[feat] <= rfThreshold[treeIdx][node]) node = rfLeft[treeIdx][node];
            else node = rfRight[treeIdx][node];
        }
        return rfValue[treeIdx][node];
    }

    public int predictScore(String battingTeam, String bowlingTeam, String venue, String tossWinner, String tossDecision, int wickets, double runRate, boolean isPlayoff) {
        int t1 = teamEnc.getOrDefault(battingTeam, 0);
        int t2 = teamEnc.getOrDefault(bowlingTeam, 0);
        int ven = venueEnc.getOrDefault(normalizeVenue(venue), 0);
        int tw = teamEnc.getOrDefault(tossWinner, 0);
        int td = decEnc.getOrDefault(tossDecision, 0);
        int bat = tossDecision.equals("bat") ? 1 : 0;
        double pressure = wickets * runRate;
        double[] features = {t1, t2, ven, tw, td, bat, wickets, 10-wickets, runRate, pressure, isPlayoff?1:0};
        double pred = gbInitScore;
        for (int t = 0; t < gbNTrees; t++) pred += gbLearningRate * traverseGB(t, features);
        return Math.max(90, Math.min(260, (int) Math.round(pred)));
    }

    public double predictWinProb(String battingTeam, String bowlingTeam, String venue, String tossWinner, String tossDecision, int wickets, double runRate, boolean isPlayoff) {
        int t1 = teamEnc.getOrDefault(battingTeam, 0);
        int t2 = teamEnc.getOrDefault(bowlingTeam, 0);
        int ven = venueEnc.getOrDefault(normalizeVenue(venue), 0);
        int tw = teamEnc.getOrDefault(tossWinner, 0);
        int td = decEnc.getOrDefault(tossDecision, 0);
        int bat = tossDecision.equals("bat") ? 1 : 0;
        double[] features = {t1, t2, ven, tw, td, bat, wickets};
        double sumClass1 = 0;
        for (int t = 0; t < rfNTrees; t++) {
            double[] vals = traverseRF(t, features);
            double total = vals[0] + vals[1];
            if (total > 0) sumClass1 += vals[1] / total;
        }
        double prob = (sumClass1 / rfNTrees) * 100.0;
        return Math.max(5.0, Math.min(95.0, prob));
    }

    public String getModelInfo() {
        return "Score: Gradient Boosting | Win: Random Forest (Clamped 5-95%)";
    }

    private int[] toIntArray(JSONArray arr) throws Exception {
        int[] result = new int[arr.length()];
        for (int i = 0; i < arr.length(); i++) result[i] = arr.getInt(i);
        return result;
    }
    private double[] toDoubleArray(JSONArray arr) throws Exception {
        double[] result = new double[arr.length()];
        for (int i = 0; i < arr.length(); i++) result[i] = arr.getDouble(i);
        return result;
    }
}
