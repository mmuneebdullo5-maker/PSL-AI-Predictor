package com.psl.predictor;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.card.MaterialCardView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ((MaterialCardView) findViewById(R.id.cardPredict))
            .setOnClickListener(v -> startActivity(new Intent(this, PredictActivity.class)));
        ((MaterialCardView) findViewById(R.id.cardTeams))
            .setOnClickListener(v -> startActivity(new Intent(this, TeamStatsActivity.class)));
        ((MaterialCardView) findViewById(R.id.cardPlayers))
            .setOnClickListener(v -> startActivity(new Intent(this, PlayersActivity.class)));
        ((MaterialCardView) findViewById(R.id.cardHistory))
            .setOnClickListener(v -> startActivity(new Intent(this, HistoryActivity.class)));
    }
}
