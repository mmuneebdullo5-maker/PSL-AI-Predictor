package com.psl.predictor;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import com.google.android.material.slider.Slider;
import java.util.ArrayList;
import java.util.List;

public class PredictActivity extends AppCompatActivity {

    private Spinner  spinnerBat, spinnerBowl, spinnerVenue, spinnerToss, spinnerDec;
    private Slider   sliderWkts, sliderRR;
    private TextView tvWkts, tvRR;
    private Switch   switchPlayoff;
    private MaterialButton        btnPredict;
    private MaterialCardView      cardResult;
    private TextView tvScore, tvWin, tvLose, tvInsight, tvMatchup, tvModelInfo;
    private LinearProgressIndicator progressWin;
    private DataManager dm;
    private MLEngine    ml;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_predict);
        dm = DataManager.getInstance(this);
        ml = MLEngine.getInstance(this);

        spinnerBat   = findViewById(R.id.spinnerBat);
        spinnerBowl  = findViewById(R.id.spinnerBowl);
        spinnerVenue = findViewById(R.id.spinnerVenue);
        spinnerToss  = findViewById(R.id.spinnerToss);
        spinnerDec   = findViewById(R.id.spinnerDec);
        sliderWkts   = findViewById(R.id.sliderWkts);
        sliderRR     = findViewById(R.id.sliderRR);
        tvWkts       = findViewById(R.id.tvWktsVal);
        tvRR         = findViewById(R.id.tvRRVal);
        switchPlayoff= findViewById(R.id.switchPlayoff);
        btnPredict   = findViewById(R.id.btnPredict);
        cardResult   = findViewById(R.id.cardResult);
        tvScore      = findViewById(R.id.tvScore);
        tvWin        = findViewById(R.id.tvWin);
        tvLose       = findViewById(R.id.tvLose);
        tvInsight    = findViewById(R.id.tvInsight);
        tvMatchup    = findViewById(R.id.tvMatchup);
        tvModelInfo  = findViewById(R.id.tvModelInfo);
        progressWin  = findViewById(R.id.progressWin);

        tvModelInfo.setText("🤖 " + ml.getModelInfo());
        setupSpinners();
        setupSliders();
        btnPredict.setOnClickListener(v -> predict());
    }

    private void setupSpinners() {
        List<String> teams = new ArrayList<>();
        teams.add("Select Team");
        teams.addAll(dm.getTeamNames());

        List<String> venues = new ArrayList<>();
        venues.add("Select Venue");
        venues.addAll(dm.getVenues());

        ArrayAdapter<String> teamAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, teams);
        teamAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerBat.setAdapter(teamAdapter);
        spinnerBowl.setAdapter(teamAdapter);

        // Toss Spinner initial state
        updateTossSpinner();

        // Listen for changes in Batting/Bowling teams to update Toss Spinner
        AdapterView.OnItemSelectedListener teamListener = new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                updateTossSpinner();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        };

        spinnerBat.setOnItemSelectedListener(teamListener);
        spinnerBowl.setOnItemSelectedListener(teamListener);

        ArrayAdapter<String> venueAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, venues);
        venueAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerVenue.setAdapter(venueAdapter);

        ArrayAdapter<String> decAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, new String[]{"bat","field"});
        decAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerDec.setAdapter(decAdapter);
    }

    private void updateTossSpinner() {
        String team1 = spinnerBat.getSelectedItem() != null ? spinnerBat.getSelectedItem().toString() : "Select Team";
        String team2 = spinnerBowl.getSelectedItem() != null ? spinnerBowl.getSelectedItem().toString() : "Select Team";

        List<String> tossTeams = new ArrayList<>();
        tossTeams.add("Select Toss Winner");
        
        if (!team1.equals("Select Team")) tossTeams.add(team1);
        if (!team2.equals("Select Team") && !team2.equals(team1)) tossTeams.add(team2);

        ArrayAdapter<String> tossAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, tossTeams);
        tossAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerToss.setAdapter(tossAdapter);
    }

    private void setupSliders() {
        sliderWkts.addOnChangeListener((s, v, f) -> tvWkts.setText(String.valueOf((int) v)));
        sliderRR  .addOnChangeListener((s, v, f) -> tvRR.setText(String.format("%.1f", v)));
    }

    private void predict() {
        String bat  = spinnerBat.getSelectedItem().toString();
        String bowl = spinnerBowl.getSelectedItem().toString();
        String ven  = spinnerVenue.getSelectedItem().toString();
        String toss = spinnerToss.getSelectedItem().toString();
        String dec  = spinnerDec.getSelectedItem().toString();
        int    wkts = (int) sliderWkts.getValue();
        double rr   = sliderRR.getValue();
        boolean playoff = switchPlayoff.isChecked();

        if (bat.equals("Select Team") || bowl.equals("Select Team") || ven.equals("Select Venue") || toss.equals("Select Toss Winner")) {
            Toast.makeText(this, "Please select all fields!", Toast.LENGTH_SHORT).show();
            return;
        }

        if (bat.equals(bowl)) {
            Toast.makeText(this, "Batting aur Bowling team alag chunein!", Toast.LENGTH_SHORT).show();
            return;
        }

        // ══ REAL ML PREDICTION ══════════════════════════════
        int    score    = ml.predictScore(bat, bowl, ven, toss, dec, wkts, rr, playoff);
        double winProb  = ml.predictWinProb(bat, bowl, ven, toss, dec, wkts, rr, playoff);
        double loseProb = 100.0 - winProb;
        // ════════════════════════════════════════════════════

        tvMatchup.setText(bat + "  vs  " + bowl);
        tvScore.setText(score + " runs");
        tvWin.setText(String.format("%.1f%%", winProb));
        tvLose.setText(String.format("%.1f%%", loseProb));
        progressWin.setProgress((int) winProb);

        String insight;
        if (winProb >= 70)
            insight = "💪 " + bat + " dominant hai! Strong win expected.\n📊 Gradient Boosting Model";
        else if (winProb >= 55)
            insight = "⚔️ Close match! " + bat + " thoda aage hai.\n📊 Gradient Boosting Model";
        else if (winProb >= 40)
            insight = "🏃 " + bowl + " ka control hai. Batting team ko accelerate karna hoga!\n📊 Random Forest Model";
        else
            insight = "⚠️ " + bat + " mushkil mein! Wickets + RR critical.\n📊 Random Forest Model";

        tvInsight.setText(insight);
        cardResult.setVisibility(View.VISIBLE);
    }
}
