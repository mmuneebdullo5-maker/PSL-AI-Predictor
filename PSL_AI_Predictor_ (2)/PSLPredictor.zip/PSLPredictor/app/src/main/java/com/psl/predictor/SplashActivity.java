package com.psl.predictor;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AppCompatActivity;

public class SplashActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        
        // Background mein data load karein
        new Thread(() -> {
            DataManager.getInstance(SplashActivity.this);
            MLEngine.getInstance(SplashActivity.this);
        }).start();

        // 2.5 seconds baad LoginActivity par jayein
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        }, 2500);
    }
}
